from __future__ import absolute_import

from scrapy import Request
from scrapy.linkextractors import LinkExtractor
from scrapy.loader import ItemLoader
from scrapy.loader.processors import Identity
from scrapy.spiders import Rule

from ..utils.spiders import BasePortiaSpider
from ..utils.starturls import FeedGenerator, FragmentGenerator
from ..utils.processors import Item, Field, Text, Number, Price, Date, Url, Image, Regex
from ..items import PortiaItem


class Bmwdealerships(BasePortiaSpider):
    name = "BMWDealerships"
    allowed_domains = [
        u'www.bmwofcatonsville.com',
        u'www.bmwofsilverspring.com',
        u'www.northwestbmw.com',
        u'www.passportbmw.com',
        u'www.bmwoftowson.com',
        u'www.bmwofannapolis.com']
    start_urls = [
        u'https://www.bmwoftowson.com/new-inventory/index.htm?search=&superModel=BMW+i&normalExteriorColor=&bodyStyle=Sedan&saveFacetState=true&lastFacetInteracted=inventory-listing1-facet-anchor-bodyStyle-0',
        u'http://www.bmwofsilverspring.com/new-inventory/index.htm?search=&saveFacetState=true&model=i3&payment-selection=payment-panel-paymentLoan&lastFacetInteracted=inventory-listing1-facet-anchor-model-11',
        u'http://www.bmwofannapolis.com/new-inventory/index.htm?search=&superModel=BMW+i&model=i3&saveFacetState=true&lastFacetInteracted=inventory-listing1-facet-anchor-model-0',
        u'http://www.bmwofcatonsville.com/new-inventory/index.htm?search=&saveFacetState=true&model=i3&lastFacetInteracted=inventory-listing1-facet-anchor-model-15',
        u'https://www.northwestbmw.com/new-inventory/index.htm?search=&superModel=BMW+i&bodyStyle=Sedan&engine=&trim=&normalTransmission=&saveFacetState=true&lastFacetInteracted=inventory-listing1-facet-anchor-bodyStyle-1',
        u'http://www.passportbmw.com/searchnew.aspx?sv=~i3']
    rules = [
        Rule(
            LinkExtractor(
                allow=(),
                deny=('.*')
            ),
            callback='parse_item',
            follow=True
        )
    ]
    items = [
        [
            Item(
                PortiaItem, None, '', [
                    Field(
                        u'container', '', []), Field(
                        u'body', '', []), Field(
                            u'exteriorcolor', '', []), Field(
                                u'trim', '', []), Field(
                                    u'vin', '', []), Field(
                                        u'year', '', []), Field(
                                            u'MSRP', '', [])]), Item(
                                                PortiaItem, None, '', [
                                                    Field(
                                                        u'container', '', []), Field(
                                                            u'body', '', []), Field(
                                                                u'exteriorcolor', '', []), Field(
                                                                    u'trim', '', []), Field(
                                                                        u'vin', '', []), Field(
                                                                            u'year', '', []), Field(
                                                                                u'MSRP', '', [])]), Item(
                                                                                    PortiaItem, None, '', [
                                                                                        Field(
                                                                                            u'container', '', []), Field(
                                                                                                u'body', '', []), Field(
                                                                                                    u'exteriorcolor', '', []), Field(
                                                                                                        u'trim', '', []), Field(
                                                                                                            u'vin', '', []), Field(
                                                                                                                u'year', '', []), Field(
                                                                                                                    u'MSRP', '', [])]), Item(
                                                                                                                        PortiaItem, None, '', [
                                                                                                                            Field(
                                                                                                                                u'container', '', []), Field(
                                                                                                                                    u'body', '', []), Field(
                                                                                                                                        u'exteriorcolor', '', []), Field(
                                                                                                                                            u'trim', '', []), Field(
                                                                                                                                                u'vin', '', []), Field(
                                                                                                                                                    u'year', '', []), Field(
                                                                                                                                                        u'MSRP', '', [])]), Item(
                                                                                                                                                            PortiaItem, None, '', [
                                                                                                                                                                Field(
                                                                                                                                                                    u'container', '', []), Field(
                                                                                                                                                                        u'body', '', []), Field(
                                                                                                                                                                            u'exteriorcolor', '', []), Field(
                                                                                                                                                                                u'trim', '', []), Field(
                                                                                                                                                                                    u'vin', '', []), Field(
                                                                                                                                                                                        u'year', '', []), Field(
                                                                                                                                                                                            u'MSRP', '', [])])]]
